﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters;
using System.IO;

namespace Server毕业设计
{
    class Compilation
    {
        //序列化DataSet为Xml
        public string CompilationDataSet(DataSet ds,string mes)
        {
            MemoryStream ms = new MemoryStream();
            ds.WriteXmlSchema(ms);
            MemoryStream stream = new MemoryStream();
            ds.WriteXml(stream,XmlWriteMode.DiffGram);
            string msg ="DataSet"+ mes +"|"+ Convert.ToBase64String(ms.ToArray()) + "|" + Convert.ToBase64String(stream.ToArray());
            return msg;
        }
    }
}
