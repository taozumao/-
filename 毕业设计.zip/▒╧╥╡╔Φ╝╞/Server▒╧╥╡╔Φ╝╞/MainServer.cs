﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Net;
using System.Net.Sockets;
using System.Windows.Forms;

namespace Server毕业设计
{
    public partial class MainServer : Form
    {
        public MainServer(object obj)
        {
            InitializeComponent();
            toppanel.Controls.Add(Menu1);
            rightpanel.Controls.Add(tabControls);
            leftpanel.Controls.Add(leftlb1);
            leftpanel.Controls.Add(leftlb2);
            rightpanel.Controls.Add(toolStrip1);
            muser.AutoGenerateColumns = false;
            nostatue.AutoGenerateColumns = false;
            yesstatue.AutoGenerateColumns = false;
            System.Windows.Forms.TextBox.CheckForIllegalCrossThreadCalls = false;
            slink = (Slink)obj;
        }
        /*
        #region
        private System.ServiceModel.ServiceHost serviceHost = null;
        protected void OnStart(string[] args)
        {
            try
            {
                serviceHost = new System.ServiceModel.ServiceHost(typeof(Graduation_Project.Project));
                if(serviceHost.State!=System.ServiceModel.CommunicationState.Opened)
                {
                    serviceHost.Open();
                }
            }catch(Exception e) { }
        }
        protected void Onstop()
        {
            if (serviceHost != null)
            {
                serviceHost.Close();
            }
        }

        #endregion*/

        int count = 0;//总数据数量
        int dataamount = 0;//分页数据数量
        int Pageamount = 0;//页数
        int datagridView = 1;
        Slink slink = new Slink();
        private void Main_Server_Load(object sender, EventArgs e)
        {
            
            basedata();
        }
        //初始化数据
        private void basedata()
        {
            SData data = new SData();
            Slink slink = new Slink();
            DataSet dt = data.basePage(out count, out dataamount, datagridView);
            if (datagridView == 1)
            {
                muser.DataSource = dt.Tables[0];
            }
            else if (datagridView == 2)
            {
                nostatue.DataSource = dt.Tables[0];
            }
            else { yesstatue.DataSource = dt.Tables[0]; }
            allPage.Text = "共" + count + "条数据";
            if (count % dataamount == 0)
            {
                Pageamount = count / dataamount;
            }
            else { Pageamount = count / dataamount + 1; }
        }
        //关于
        private void menuto_Click(object sender, EventArgs e)
        {
            GuanYu gy = new GuanYu();
            gy.StartPosition = FormStartPosition.Manual;
            gy.Location = new System.Drawing.Point(this.Location.X + (this.Width - gy.Width) / 2, this.Location.Y + (this.Height - gy.Height) / 2);
            gy.ShowDialog();
        }
        //退出
        private void quit_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Login login = new Login();
            login.Owner = this;
            this.Hide();
            login.ShowDialog();
            System.Windows.Forms.Application.ExitThread();
        }
        #region
        //首页
        private void first_Click(object sender, EventArgs e)
        {
            if (count > 0)
            {
                Page.Text = "1";
                SData first = new SData();
                DataSet ds = first.Page(Page.Text, datagridView);
                if (datagridView == 1)
                {
                    muser.DataSource = ds.Tables[0];
                }
                else if (datagridView == 2)
                {
                    nostatue.DataSource = ds.Tables[0];
                }
                else { yesstatue.DataSource = ds.Tables[0]; }
            }
        }
        //上一页
        private void front_Click(object sender, EventArgs e)
        {
            if (count > 0)
            {
                if (Page.Text == "1")
                {
                    first_Click(sender, e);
                }
                else
                {
                    Page.Text = (int.Parse(Page.Text) - 1).ToString();
                    SData front = new SData();
                    DataSet ds = front.Page(Page.Text, datagridView);
                    if (datagridView == 1)
                    {
                        muser.DataSource = ds.Tables[0];
                    }
                    else if (datagridView == 2)
                    {
                        nostatue.DataSource = ds.Tables[0];
                    }
                    else { yesstatue.DataSource = ds.Tables[0]; }
                }
            }
        }
        //下一页
        private void after_Click(object sender, EventArgs e)
        {
            if (count > 0)
            {
                if (int.Parse(Page.Text) < Pageamount)
                {
                    Page.Text = (int.Parse(Page.Text) + 1).ToString();
                    SData after = new SData();
                    DataSet ds = after.Page(Page.Text, datagridView);
                    if (datagridView == 1)
                    {
                        muser.DataSource = ds.Tables[0];
                    }
                    else if (datagridView == 2)
                    {
                        nostatue.DataSource = ds.Tables[0];
                    }
                    else { yesstatue.DataSource = ds.Tables[0]; }
                }
                else { last_Click(sender, e); }
            }
        }
        //末页
        private void last_Click(object sender, EventArgs e)
        {
            if (count > 0)
            {
                Page.Text = Pageamount.ToString();
                SData last = new SData();
                DataSet ds = last.Page(Page.Text, datagridView);
                if (datagridView == 1)
                {
                    muser.DataSource = ds.Tables[0];
                }
                else if (datagridView == 2)
                {
                    nostatue.DataSource = ds.Tables[0];
                }
                else { yesstatue.DataSource = ds.Tables[0]; }
            }
        }
        //跳转
        private void jump_Click(object sender, EventArgs e)
        {
            if (count > 0)
            {
                if (int.Parse(Page.Text) > Pageamount)
                {
                    Page.Text = Pageamount.ToString();
                }
                if (int.Parse(Page.Text) < 1)
                {
                    Page.Text = "1";
                }
                SData jump = new SData();
                DataSet ds = jump.Page(Page.Text, datagridView);
                if (datagridView == 1)
                {
                    muser.DataSource = ds.Tables[0];
                }
                else if (datagridView == 2)
                {
                    nostatue.DataSource = ds.Tables[0];
                }
                else { yesstatue.DataSource = ds.Tables[0]; }
            }
        }
        #endregion
        //选项卡点击
        private void tabControls_Click(object sender, EventArgs e)
        {
            
            Page.Text = "1";
            if (tabControls.SelectedTab.Text == "用户")
            {
                datagridView = 1;
                basedata();
            }
            else if (tabControls.SelectedTab.Text == "未审批")
            {
                datagridView = 2;
                basedata();
            }
            else
            {
                datagridView = 3;
                basedata();
            }
        }
        //审批
        private void nostatue_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewColumn viewColumn = nostatue.Columns[e.ColumnIndex];
                if (viewColumn is DataGridViewLinkColumn)
                {
                    if (MessageBox.Show("是否审批？", "提问", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    {
                        SData data = new SData();
                        data.status(nostatue.CurrentRow.Cells["noId"].Value.ToString());
                        basedata();
                        jump_Click(sender, e);
                    }
                }
            }
        }
        //导出Excel
        private void export_Click(object sender, EventArgs e)
        {
            SaveFileDialog open = new SaveFileDialog { Filter = "所有文件(*xls)|*.xls" };
            open.FilterIndex = 1;
            open.RestoreDirectory = true;
            if (open.ShowDialog() == DialogResult.OK)
            {
                SData dt = new SData();
                DataSet ds = dt.Export(datagridView);
                Microsoft.Office.Interop.Excel.Application application = new Microsoft.Office.Interop.Excel.Application();
                if (application == null)
                { MessageBox.Show("没有安装office！"); return; }
                //application.Visible = false;
                //application.UserControl = true;
                Microsoft.Office.Interop.Excel.Workbook workbook = application.Workbooks.Add(Microsoft.Office.Interop.Excel.XlWBATemplate.xlWBATWorksheet);
                Microsoft.Office.Interop.Excel.Worksheet worksheet = (Microsoft.Office.Interop.Excel.Worksheet)workbook.Worksheets[1];
                //Microsoft.Office.Interop.Excel.Range range;
                if (datagridView == 1)
                {
                    ProgressBar.Maximum = (muser.ColumnCount-2) * count;
                    //range = worksheet.ra[application.Cells[1][1], application.Cells[1][muser.ColumnCount]];
                    worksheet.Name = "用户数据";
                    for (int i = 1; i < muser.ColumnCount; i++)
                    {
                        worksheet.Cells[1, i + 1] = muser.Columns[i].HeaderText;
                        for (int j = 0; j < count; j++)
                        {
                            worksheet.Cells[j + 2, i + 1] = ds.Tables[0].Rows[j][muser.Columns[i].DataPropertyName];
                            ProgressBar.PerformStep();
                        }
                    }
                }
                else if (datagridView == 2)
                {
                    ProgressBar.Maximum = (nostatue.ColumnCount-2) * count;
                    //range = worksheet.Range[application.Cells[1][1], application.Cells[1][nostatue.ColumnCount]];
                    worksheet.Name = "未审批数据";
                    for (int i = 1; i < nostatue.ColumnCount; i++)
                    {
                        worksheet.Cells[1, i + 1] = nostatue.Columns[i].HeaderText;
                        for (int j = 0; j < count; j++)
                        {
                            ProgressBar.PerformStep();
                            worksheet.Cells[j + 2, i + 1] = ds.Tables[0].Rows[j][nostatue.Columns[i].DataPropertyName];
                        }
                    }
                }
                else
                {
                    ProgressBar.Maximum = (yesstatue.ColumnCount-2) * count;
                    //range = worksheet.Range[application.Cells[1][1], application.Cells[1][yesstatue.ColumnCount]];
                    worksheet.Name = "已审批数据";
                    for (int i = 1; i < yesstatue.ColumnCount; i++)
                    {
                        worksheet.Cells[1, i + 1] = yesstatue.Columns[i].HeaderText;
                        for (int j = 0; j < count; j++)
                        {
                            ProgressBar.PerformStep();
                            worksheet.Cells[j + 2, i + 1] = ds.Tables[0].Rows[j][yesstatue.Columns[i].DataPropertyName];
                        }
                    }
                }

                //range.Merge(Type.Missing);
                //range.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlVAlign.xlVAlignCenter;
                try
                {
                    //worksheet.get_Range(application.Cells[1][1], application.Cells[100][100]).HorizontalAlignment = Microsoft.Office.Interop.Excel.XlVAlign.xlVAlignCenter;
                    workbook.Saved = true;
                    workbook.SaveCopyAs(open.FileName);
                }catch(Exception ex) { MessageBox.Show("文件已被打开！"); }
                
                //workbook.SaveAs(open.FileName, Microsoft.Office.Interop.Excel.XlFileFormat.xlWorkbookNormal, "", "", "", "", Microsoft.Office.Interop.Excel.XlSaveAsAccessMode.xlNoChange, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);
                application.Visible = false;
                //ReleaseObject(range);
                ReleaseObject(worksheet);
                ReleaseObject(workbook);
                application.Quit();
                int w = System.GC.GetGeneration(application);
                application = null;
                System.GC.Collect(w);
            }
            
        }
        //释放Excel资源
        public static void ReleaseObject(object obj)
        {
            try
            {
                if (obj != null)
                {
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(obj);
                }
            }
            catch { }
            finally
            {
                obj = null;
            }
        }

        private void MainServer_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (MessageBox.Show("关闭窗口？", "提示", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                slink.OnStop();
                Environment.Exit(0);
            }
        }
    }
}
