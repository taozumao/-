﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.Net.Sockets;
using System.IO;
using System.Threading;
using System.Windows.Forms;

namespace Server毕业设计
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }
        //登录
        private void Input_Click(object sender, EventArgs e)
        {
            object obj = (object)slink;
            MainServer ms = new MainServer(obj);
            ms.Owner = this;
            this.Hide();
            ms.ShowDialog();
            Application.ExitThread();
           /* if (txtname.Text == "admin" && txtpwd.Text == "111") //用户名密码验证
            {
                MainServer ms = new MainServer();
                ms.Owner = this;
                this.Hide();
                ms.ShowDialog();
                Application.ExitThread();
            }
            else
            {
                MessageBox.Show("用户名或密码错误！");
            }*/
        }
        //退出
        private void quit_Click(object sender, EventArgs e)
        {
            if(MessageBox.Show("确认关闭？","提示",MessageBoxButtons.YesNo,MessageBoxIcon.Question)==DialogResult.Yes)
            {
                slink.OnStop();
                Environment.Exit(0);
            }
        }
        Slink slink = new Slink();
        private void Login_Load(object sender, EventArgs e)
        {
            
            slink.link();
        }

        private void Login_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (MessageBox.Show("确认关闭？", "提示", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                slink.OnStop();
                Environment.Exit(0);
            }
        }
    }
}
