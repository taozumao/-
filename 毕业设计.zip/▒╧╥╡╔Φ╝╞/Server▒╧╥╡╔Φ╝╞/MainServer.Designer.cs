﻿namespace Server毕业设计
{
    partial class MainServer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainServer));
            this.toppanel = new System.Windows.Forms.Panel();
            this.quit = new System.Windows.Forms.LinkLabel();
            this.Menu1 = new System.Windows.Forms.MenuStrip();
            this.menufile = new System.Windows.Forms.ToolStripMenuItem();
            this.menutool = new System.Windows.Forms.ToolStripMenuItem();
            this.menuto = new System.Windows.Forms.ToolStripMenuItem();
            this.leftpanel = new System.Windows.Forms.Panel();
            this.leftlb2 = new System.Windows.Forms.Label();
            this.leftlb1 = new System.Windows.Forms.Label();
            this.rightpanel = new System.Windows.Forms.Panel();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.first = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.front = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.after = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.last = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.Page = new System.Windows.Forms.ToolStripTextBox();
            this.jump = new System.Windows.Forms.ToolStripButton();
            this.allPage = new System.Windows.Forms.ToolStripLabel();
            this.export = new System.Windows.Forms.ToolStripButton();
            this.ProgressBar = new System.Windows.Forms.ToolStripProgressBar();
            this.tabControls = new System.Windows.Forms.TabControl();
            this.tabuser = new System.Windows.Forms.TabPage();
            this.muser = new System.Windows.Forms.DataGridView();
            this.ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataprincipal = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataphone = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataemail = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.datapswd = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabnstaute = new System.Windows.Forms.TabPage();
            this.nostatue = new System.Windows.Forms.DataGridView();
            this.noId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.company = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataprof = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.amount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.State = new System.Windows.Forms.DataGridViewLinkColumn();
            this.fronttime = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.aftertime = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabystaute = new System.Windows.Forms.TabPage();
            this.yesstatue = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.statecolumn = new System.Windows.Forms.DataGridViewLinkColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.userBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.toppanel.SuspendLayout();
            this.Menu1.SuspendLayout();
            this.leftpanel.SuspendLayout();
            this.rightpanel.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.tabControls.SuspendLayout();
            this.tabuser.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.muser)).BeginInit();
            this.tabnstaute.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nostatue)).BeginInit();
            this.tabystaute.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.yesstatue)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.userBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // toppanel
            // 
            this.toppanel.Controls.Add(this.quit);
            this.toppanel.Controls.Add(this.Menu1);
            this.toppanel.Location = new System.Drawing.Point(0, 0);
            this.toppanel.Name = "toppanel";
            this.toppanel.Size = new System.Drawing.Size(546, 31);
            this.toppanel.TabIndex = 0;
            // 
            // quit
            // 
            this.quit.AutoSize = true;
            this.quit.Location = new System.Drawing.Point(494, 9);
            this.quit.Name = "quit";
            this.quit.Size = new System.Drawing.Size(29, 12);
            this.quit.TabIndex = 1;
            this.quit.TabStop = true;
            this.quit.Text = "注销";
            this.quit.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.quit_LinkClicked);
            // 
            // Menu1
            // 
            this.Menu1.Dock = System.Windows.Forms.DockStyle.None;
            this.Menu1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menufile,
            this.menutool,
            this.menuto});
            this.Menu1.Location = new System.Drawing.Point(2, 3);
            this.Menu1.Name = "Menu1";
            this.Menu1.Size = new System.Drawing.Size(140, 25);
            this.Menu1.TabIndex = 0;
            this.Menu1.Text = "menuStrip1";
            // 
            // menufile
            // 
            this.menufile.Name = "menufile";
            this.menufile.Size = new System.Drawing.Size(44, 21);
            this.menufile.Text = "文件";
            // 
            // menutool
            // 
            this.menutool.Name = "menutool";
            this.menutool.Size = new System.Drawing.Size(44, 21);
            this.menutool.Text = "工具";
            // 
            // menuto
            // 
            this.menuto.Name = "menuto";
            this.menuto.Size = new System.Drawing.Size(44, 21);
            this.menuto.Text = "关于";
            this.menuto.Click += new System.EventHandler(this.menuto_Click);
            // 
            // leftpanel
            // 
            this.leftpanel.Controls.Add(this.leftlb2);
            this.leftpanel.Controls.Add(this.leftlb1);
            this.leftpanel.Location = new System.Drawing.Point(0, 31);
            this.leftpanel.Name = "leftpanel";
            this.leftpanel.Size = new System.Drawing.Size(70, 257);
            this.leftpanel.TabIndex = 2;
            // 
            // leftlb2
            // 
            this.leftlb2.AutoSize = true;
            this.leftlb2.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.leftlb2.Location = new System.Drawing.Point(36, 98);
            this.leftlb2.Name = "leftlb2";
            this.leftlb2.Size = new System.Drawing.Size(26, 66);
            this.leftlb2.TabIndex = 1;
            this.leftlb2.Text = "管\r\n理\r\n员";
            // 
            // leftlb1
            // 
            this.leftlb1.AutoSize = true;
            this.leftlb1.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.leftlb1.Location = new System.Drawing.Point(4, 85);
            this.leftlb1.Name = "leftlb1";
            this.leftlb1.Size = new System.Drawing.Size(26, 88);
            this.leftlb1.TabIndex = 0;
            this.leftlb1.Text = "欢\r\n迎\r\n您\r\n !";
            // 
            // rightpanel
            // 
            this.rightpanel.Controls.Add(this.toolStrip1);
            this.rightpanel.Controls.Add(this.tabControls);
            this.rightpanel.Location = new System.Drawing.Point(70, 31);
            this.rightpanel.Name = "rightpanel";
            this.rightpanel.Size = new System.Drawing.Size(476, 257);
            this.rightpanel.TabIndex = 3;
            // 
            // toolStrip1
            // 
            this.toolStrip1.Dock = System.Windows.Forms.DockStyle.None;
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.first,
            this.toolStripSeparator1,
            this.front,
            this.toolStripSeparator2,
            this.after,
            this.toolStripSeparator3,
            this.last,
            this.toolStripSeparator4,
            this.Page,
            this.jump,
            this.allPage,
            this.export,
            this.ProgressBar});
            this.toolStrip1.Location = new System.Drawing.Point(3, 225);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(454, 25);
            this.toolStrip1.TabIndex = 1;
            this.toolStrip1.Text = "分页";
            // 
            // first
            // 
            this.first.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.first.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.first.Name = "first";
            this.first.Size = new System.Drawing.Size(36, 22);
            this.first.Text = "首页";
            this.first.Click += new System.EventHandler(this.first_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // front
            // 
            this.front.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.front.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.front.Name = "front";
            this.front.Size = new System.Drawing.Size(48, 22);
            this.front.Text = "上一页";
            this.front.Click += new System.EventHandler(this.front_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // after
            // 
            this.after.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.after.Image = ((System.Drawing.Image)(resources.GetObject("after.Image")));
            this.after.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.after.Name = "after";
            this.after.Size = new System.Drawing.Size(48, 22);
            this.after.Text = "下一页";
            this.after.ToolTipText = "下一页";
            this.after.Click += new System.EventHandler(this.after_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(6, 25);
            // 
            // last
            // 
            this.last.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.last.Image = ((System.Drawing.Image)(resources.GetObject("last.Image")));
            this.last.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.last.Name = "last";
            this.last.Size = new System.Drawing.Size(36, 22);
            this.last.Text = "末页";
            this.last.ToolTipText = "末页";
            this.last.Click += new System.EventHandler(this.last_Click);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(6, 25);
            // 
            // Page
            // 
            this.Page.Name = "Page";
            this.Page.Size = new System.Drawing.Size(20, 25);
            this.Page.Text = "1";
            // 
            // jump
            // 
            this.jump.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.jump.Image = ((System.Drawing.Image)(resources.GetObject("jump.Image")));
            this.jump.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.jump.Name = "jump";
            this.jump.Size = new System.Drawing.Size(36, 22);
            this.jump.Text = "跳转";
            this.jump.Click += new System.EventHandler(this.jump_Click);
            // 
            // allPage
            // 
            this.allPage.Name = "allPage";
            this.allPage.Size = new System.Drawing.Size(54, 22);
            this.allPage.Text = "共**数据";
            // 
            // export
            // 
            this.export.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.export.Image = ((System.Drawing.Image)(resources.GetObject("export.Image")));
            this.export.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.export.Name = "export";
            this.export.Size = new System.Drawing.Size(36, 22);
            this.export.Text = "导出";
            this.export.Click += new System.EventHandler(this.export_Click);
            // 
            // ProgressBar
            // 
            this.ProgressBar.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.ProgressBar.Name = "ProgressBar";
            this.ProgressBar.Size = new System.Drawing.Size(100, 22);
            this.ProgressBar.Step = 1;
            this.ProgressBar.Tag = "";
            // 
            // tabControls
            // 
            this.tabControls.Controls.Add(this.tabuser);
            this.tabControls.Controls.Add(this.tabnstaute);
            this.tabControls.Controls.Add(this.tabystaute);
            this.tabControls.Location = new System.Drawing.Point(0, 0);
            this.tabControls.Name = "tabControls";
            this.tabControls.SelectedIndex = 0;
            this.tabControls.Size = new System.Drawing.Size(476, 221);
            this.tabControls.TabIndex = 0;
            this.tabControls.Click += new System.EventHandler(this.tabControls_Click);
            // 
            // tabuser
            // 
            this.tabuser.Controls.Add(this.muser);
            this.tabuser.Location = new System.Drawing.Point(4, 22);
            this.tabuser.Name = "tabuser";
            this.tabuser.Padding = new System.Windows.Forms.Padding(3);
            this.tabuser.Size = new System.Drawing.Size(468, 195);
            this.tabuser.TabIndex = 0;
            this.tabuser.Text = "用户";
            this.tabuser.UseVisualStyleBackColor = true;
            // 
            // muser
            // 
            this.muser.AllowUserToAddRows = false;
            this.muser.AllowUserToDeleteRows = false;
            this.muser.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.muser.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ID,
            this.dataName,
            this.dataprincipal,
            this.dataphone,
            this.dataemail,
            this.datapswd});
            this.muser.Dock = System.Windows.Forms.DockStyle.Fill;
            this.muser.Location = new System.Drawing.Point(3, 3);
            this.muser.Name = "muser";
            this.muser.ReadOnly = true;
            this.muser.RowTemplate.Height = 23;
            this.muser.Size = new System.Drawing.Size(462, 189);
            this.muser.TabIndex = 0;
            // 
            // ID
            // 
            this.ID.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.ID.DataPropertyName = "Id";
            this.ID.HeaderText = "位置";
            this.ID.Name = "ID";
            this.ID.ReadOnly = true;
            this.ID.Visible = false;
            // 
            // dataName
            // 
            this.dataName.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataName.DataPropertyName = "Name";
            this.dataName.HeaderText = "名称";
            this.dataName.Name = "dataName";
            this.dataName.ReadOnly = true;
            // 
            // dataprincipal
            // 
            this.dataprincipal.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataprincipal.DataPropertyName = "Principal";
            this.dataprincipal.HeaderText = "负责人";
            this.dataprincipal.Name = "dataprincipal";
            this.dataprincipal.ReadOnly = true;
            // 
            // dataphone
            // 
            this.dataphone.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataphone.DataPropertyName = "Phone";
            this.dataphone.HeaderText = "电话";
            this.dataphone.Name = "dataphone";
            this.dataphone.ReadOnly = true;
            // 
            // dataemail
            // 
            this.dataemail.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataemail.DataPropertyName = "Email";
            this.dataemail.HeaderText = "邮箱";
            this.dataemail.Name = "dataemail";
            this.dataemail.ReadOnly = true;
            // 
            // datapswd
            // 
            this.datapswd.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.datapswd.DataPropertyName = "Psword";
            this.datapswd.HeaderText = "密码";
            this.datapswd.Name = "datapswd";
            this.datapswd.ReadOnly = true;
            // 
            // tabnstaute
            // 
            this.tabnstaute.Controls.Add(this.nostatue);
            this.tabnstaute.Location = new System.Drawing.Point(4, 22);
            this.tabnstaute.Name = "tabnstaute";
            this.tabnstaute.Padding = new System.Windows.Forms.Padding(3);
            this.tabnstaute.Size = new System.Drawing.Size(468, 195);
            this.tabnstaute.TabIndex = 1;
            this.tabnstaute.Text = "未审批";
            this.tabnstaute.UseVisualStyleBackColor = true;
            // 
            // nostatue
            // 
            this.nostatue.AllowUserToAddRows = false;
            this.nostatue.AllowUserToDeleteRows = false;
            this.nostatue.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.nostatue.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.noId,
            this.company,
            this.dataprof,
            this.amount,
            this.State,
            this.fronttime,
            this.aftertime});
            this.nostatue.Dock = System.Windows.Forms.DockStyle.Fill;
            this.nostatue.Location = new System.Drawing.Point(3, 3);
            this.nostatue.Name = "nostatue";
            this.nostatue.ReadOnly = true;
            this.nostatue.RowTemplate.Height = 23;
            this.nostatue.Size = new System.Drawing.Size(462, 189);
            this.nostatue.TabIndex = 0;
            this.nostatue.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.nostatue_CellContentClick);
            // 
            // noId
            // 
            this.noId.DataPropertyName = "Id";
            this.noId.HeaderText = "位置";
            this.noId.Name = "noId";
            this.noId.ReadOnly = true;
            this.noId.Visible = false;
            // 
            // company
            // 
            this.company.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.company.DataPropertyName = "Name";
            this.company.HeaderText = "名称";
            this.company.Name = "company";
            this.company.ReadOnly = true;
            // 
            // dataprof
            // 
            this.dataprof.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataprof.DataPropertyName = "Name1";
            this.dataprof.HeaderText = "污染物";
            this.dataprof.Name = "dataprof";
            this.dataprof.ReadOnly = true;
            this.dataprof.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataprof.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // amount
            // 
            this.amount.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.amount.DataPropertyName = "Amount";
            this.amount.HeaderText = "数量";
            this.amount.Name = "amount";
            this.amount.ReadOnly = true;
            // 
            // State
            // 
            this.State.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.State.DataPropertyName = "state";
            this.State.HeaderText = "状态";
            this.State.Name = "State";
            this.State.ReadOnly = true;
            // 
            // fronttime
            // 
            this.fronttime.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.fronttime.DataPropertyName = "btime";
            this.fronttime.HeaderText = "提交时间";
            this.fronttime.Name = "fronttime";
            this.fronttime.ReadOnly = true;
            this.fronttime.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.fronttime.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // aftertime
            // 
            this.aftertime.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.aftertime.DataPropertyName = "atime";
            this.aftertime.HeaderText = "审批时间";
            this.aftertime.Name = "aftertime";
            this.aftertime.ReadOnly = true;
            this.aftertime.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.aftertime.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // tabystaute
            // 
            this.tabystaute.Controls.Add(this.yesstatue);
            this.tabystaute.Location = new System.Drawing.Point(4, 22);
            this.tabystaute.Name = "tabystaute";
            this.tabystaute.Padding = new System.Windows.Forms.Padding(3);
            this.tabystaute.Size = new System.Drawing.Size(468, 195);
            this.tabystaute.TabIndex = 2;
            this.tabystaute.Text = "已审批";
            this.tabystaute.UseVisualStyleBackColor = true;
            // 
            // yesstatue
            // 
            this.yesstatue.AllowUserToAddRows = false;
            this.yesstatue.AllowUserToDeleteRows = false;
            this.yesstatue.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.yesstatue.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.statecolumn,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5});
            this.yesstatue.Dock = System.Windows.Forms.DockStyle.Fill;
            this.yesstatue.Location = new System.Drawing.Point(3, 3);
            this.yesstatue.Name = "yesstatue";
            this.yesstatue.ReadOnly = true;
            this.yesstatue.RowTemplate.Height = 23;
            this.yesstatue.Size = new System.Drawing.Size(462, 189);
            this.yesstatue.TabIndex = 1;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn1.DataPropertyName = "Name";
            this.dataGridViewTextBoxColumn1.HeaderText = "名称";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn2.DataPropertyName = "Name1";
            this.dataGridViewTextBoxColumn2.HeaderText = "污染物";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            this.dataGridViewTextBoxColumn2.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn2.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn3.DataPropertyName = "Amount";
            this.dataGridViewTextBoxColumn3.HeaderText = "数量";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            // 
            // statecolumn
            // 
            this.statecolumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.statecolumn.DataPropertyName = "State";
            this.statecolumn.HeaderText = "状态";
            this.statecolumn.Name = "statecolumn";
            this.statecolumn.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn4.DataPropertyName = "btime";
            this.dataGridViewTextBoxColumn4.HeaderText = "提交时间";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            this.dataGridViewTextBoxColumn4.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn4.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn5.DataPropertyName = "atime";
            this.dataGridViewTextBoxColumn5.HeaderText = "审批时间";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            this.dataGridViewTextBoxColumn5.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn5.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // userBindingSource
            // 
            this.userBindingSource.DataMember = "user";
            // 
            // MainServer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(546, 290);
            this.Controls.Add(this.rightpanel);
            this.Controls.Add(this.leftpanel);
            this.Controls.Add(this.toppanel);
            this.IsMdiContainer = true;
            this.Name = "MainServer";
            this.Text = "Main_Server";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.MainServer_FormClosing);
            this.Load += new System.EventHandler(this.Main_Server_Load);
            this.toppanel.ResumeLayout(false);
            this.toppanel.PerformLayout();
            this.Menu1.ResumeLayout(false);
            this.Menu1.PerformLayout();
            this.leftpanel.ResumeLayout(false);
            this.leftpanel.PerformLayout();
            this.rightpanel.ResumeLayout(false);
            this.rightpanel.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.tabControls.ResumeLayout(false);
            this.tabuser.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.muser)).EndInit();
            this.tabnstaute.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.nostatue)).EndInit();
            this.tabystaute.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.yesstatue)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.userBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel toppanel;
        private System.Windows.Forms.MenuStrip Menu1;
        private System.Windows.Forms.ToolStripMenuItem menufile;
        private System.Windows.Forms.ToolStripMenuItem menutool;
        private System.Windows.Forms.ToolStripMenuItem menuto;
        private System.Windows.Forms.Panel leftpanel;
        private System.Windows.Forms.Panel rightpanel;
        private System.Windows.Forms.TabControl tabControls;
        private System.Windows.Forms.TabPage tabuser;
        private System.Windows.Forms.TabPage tabnstaute;
        private System.Windows.Forms.LinkLabel quit;
        private System.Windows.Forms.Label leftlb2;
        private System.Windows.Forms.Label leftlb1;
        private System.Windows.Forms.TabPage tabystaute;
        private System.Windows.Forms.DataGridView muser;
        private System.Windows.Forms.BindingSource userBindingSource;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton first;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripButton front;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripButton after;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripButton last;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripTextBox Page;
        private System.Windows.Forms.ToolStripButton jump;
        private System.Windows.Forms.ToolStripLabel allPage;
        private System.Windows.Forms.ToolStripButton export;
        private System.Windows.Forms.ToolStripProgressBar ProgressBar;
        private System.Windows.Forms.DataGridView nostatue;
        private System.Windows.Forms.DataGridView yesstatue;
        private System.Windows.Forms.DataGridViewTextBoxColumn ID;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataName;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataprincipal;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataphone;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataemail;
        private System.Windows.Forms.DataGridViewTextBoxColumn datapswd;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewLinkColumn statecolumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn noId;
        private System.Windows.Forms.DataGridViewTextBoxColumn company;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataprof;
        private System.Windows.Forms.DataGridViewTextBoxColumn amount;
        private System.Windows.Forms.DataGridViewLinkColumn State;
        private System.Windows.Forms.DataGridViewTextBoxColumn fronttime;
        private System.Windows.Forms.DataGridViewTextBoxColumn aftertime;
    }
}