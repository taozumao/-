﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Net;
using System.Net.Sockets;
using System.Data;

namespace Server毕业设计
{
    class Slink
    {
        static bool stop = true;
        static bool boolprof = true;
        Socket socket = null;
        List<string> list = new List<string>();
        Dictionary<string, Socket> dic = new Dictionary<string, Socket> { };
        //监听客户端
        public void link()
        {
            socket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            IPAddress ip = IPAddress.Parse("127.0.0.1");
            int port = 8888;
            IPEndPoint endpoint = new IPEndPoint(ip, port);
            socket.Bind(endpoint);
            socket.Listen(20);
            Thread thread = new Thread(watching);
            thread.IsBackground = true;
            thread.Start();
        }
        //持续监听终端
        private void watching()
        {
            while(stop)
            {
                Socket sock = socket.Accept();
                string point = sock.RemoteEndPoint.ToString();
                dic.Add(point, sock);
                list.Add(point);
                ParameterizedThreadStart pt = new ParameterizedThreadStart(recmsg);
                Thread th = new Thread(pt);
                th.IsBackground = true;
                th.Start(sock);
            }
        }
        //持续接收客户端信息
        SData dt = new SData();
        private void recmsg(object skt)
        {
            while (stop)
            {
                Socket st = skt as Socket;
                byte[] msg = new byte[1024 * 1024];
                int length = 0;
                //length = st.Receive(msg);
                
                try
                {
                    length = st.Receive(msg);
                }catch(Exception ex)
                {
                    list.Remove(st.RemoteEndPoint.ToString());
                    dic.Remove(st.RemoteEndPoint.ToString());
                    st.Shutdown(SocketShutdown.Both);
                }
                string message = Encoding.UTF8.GetString(msg, 0, length);
                string[] splited = message.Split('|');
                string point = st.RemoteEndPoint.ToString();
                    
                if (splited[0] == "SQL0" || splited[0] == "SQL1")
                {
                    string mes = dt.SQL(splited);
                    send(point, mes);
                }
                else if (splited[0] == "SQL2")
                {
                    if (splited.Length >= 3)
                    {
                        string mes = dt.SQL(splited);
                        send(point, mes);
                    }
                    string usermes = dt.ToClinetUser(splited[1]);
                    send(point, usermes);
                    string statemes = dt.ToClientState(splited[1]);
                    send(point, statemes);
                }
                else { }
                if (boolprof)
                {
                    string profmes = dt.ToClientProf();
                    send(point, profmes);
                    boolprof = false;
                }
            }
        }
        //发送信息到客户端
        private void send(string point,string msg)
        {
            byte[] sendmsg = Encoding.UTF8.GetBytes(msg);
            if (list.Contains(point))
            {
                dic[point].Send(sendmsg);
            }
        }

        public void OnStop()
        {
            stop = false;
            foreach(string str in list)
            {
                byte[] msg = Encoding.UTF8.GetBytes("end");
                dic[str].Send(msg);
                Thread.Sleep(1000);
                dic[str].Shutdown(SocketShutdown.Both);
                dic[str].Close();
            }
        }
    }
}
