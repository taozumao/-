﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;

namespace Server毕业设计
{
    class SData
    {
        int Dataamount = 2;//每页显示数据数量
        #region
        /*public void dataselect(string sql)
        {
            string Constr = Properties.Settings.Default.DataString;
            SqlConnection sqlserver = new SqlConnection(Constr);
            sqlserver.Open();
            SqlCommand sqlCmd = new SqlCommand(sql, sqlserver);
            int result = sqlCmd.ExecuteNonQuery();
        }*/
        #endregion

        //处理客户端发来的信息
        public string SQL(string[] sql)
        {
            string Constr = Properties.Settings.Default.DataString;
            SqlConnection sqlConnection = new SqlConnection(Constr);
            sqlConnection.Open();
            SqlCommand sqlCommand = new SqlCommand(sql[1], sqlConnection);
            int i;
            if (sql[0] == "SQL1")
            {
                i = Convert.ToInt32(sqlCommand.ExecuteScalar());
            }
            else {
                i = Convert.ToInt32(sqlCommand.ExecuteNonQuery());
            }
            sqlConnection.Close();
            return "SQL"+"|"+i.ToString();
        }
        //发送用户自身信息到客户端
        public string ToClinetUser(string email)
        {
            DataSet ds = new DataSet();
            Compilation compilation = new Compilation();
            string Constr = Properties.Settings.Default.DataString;
            SqlConnection sqlConnection = new SqlConnection(Constr);
            sqlConnection.Open();
            string sql = "select * from [dbo].[user] where Email='" + email + "'";
            SqlCommand sqlcommand = new SqlCommand(sql, sqlConnection);
            SqlDataAdapter adapter = new SqlDataAdapter(sqlcommand);
            adapter.Fill(ds);
            sqlConnection.Close();
            return compilation.CompilationDataSet(ds,"User");
        }
        //发送用户申请审批信息到客户端
        public string ToClientState(string email)
        {
            DataSet ds = new DataSet();
            Compilation compilation = new Compilation();
            string Constr = Properties.Settings.Default.DataString;
            SqlConnection sqlConnection = new SqlConnection(Constr);
            sqlConnection.Open();
            string sql = "select [dbo].[u_prof].Id,[dbo].[user].Name,[dbo].[prof].Name,Amount,State,btime,atime  from [dbo].[u_prof],[dbo].[prof],[dbo].[user] where [dbo].[user].Email='" + email + "' and [dbo].[u_prof].uId=[dbo].[user].Id and [dbo].[u_prof].pId=[dbo].[prof].Id";
            SqlCommand sqlcommand = new SqlCommand(sql, sqlConnection);
            SqlDataAdapter adapter = new SqlDataAdapter(sqlcommand);
            adapter.Fill(ds);
            sqlConnection.Close();
            return compilation.CompilationDataSet(ds,"State");
        }
        //发送污染源信息到客户端
        public string ToClientProf()
        {
            DataSet ds = new DataSet();
            Compilation compilation = new Compilation();
            string Constr = Properties.Settings.Default.DataString;
            SqlConnection sqlConnection = new SqlConnection(Constr);
            sqlConnection.Open();
            string sql = "select * from [dbo].[prof]";
            SqlCommand sqlcommand = new SqlCommand(sql, sqlConnection);
            SqlDataAdapter adapter = new SqlDataAdapter(sqlcommand);
            adapter.Fill(ds);
            sqlConnection.Close();
            return compilation.CompilationDataSet(ds, "Prof");
        }
        //输出Datagridview数据
        public DataSet Export(int i)
        {
            string Constr = Properties.Settings.Default.DataString;
            SqlConnection sqlserver = new SqlConnection(Constr);
            DataSet ds = new DataSet();
            sqlserver.Open();
            if (i == 1)
            {
                string sql = "select * from [dbo].[user]";
                SqlDataAdapter sqlData = new SqlDataAdapter(sql, sqlserver);
                sqlData.Fill(ds);
            }
            else if (i == 2)
            {
                string sql = "select [dbo].[u_prof].Id,[dbo].[user].Name,[dbo].[prof].Name,Amount,State,btime,atime  from [dbo].[u_prof],[dbo].[prof],[dbo].[user] where State='" + "待审批" + "' and [dbo].[u_prof].uId=[dbo].[user].Id and [dbo].[u_prof].pId=[dbo].[prof].Id";
                SqlDataAdapter sqlData = new SqlDataAdapter(sql, sqlserver);
                sqlData.Fill(ds);
            }
            else
            {
                string sql = "select [dbo].[u_prof].Id,[dbo].[user].Name,[dbo].[prof].Name,Amount,State,btime,atime  from [dbo].[u_prof],[dbo].[prof],[dbo].[user] where State='" + "已审批" + "' and [dbo].[u_prof].uId=[dbo].[user].Id and [dbo].[u_prof].pId=[dbo].[prof].Id";
                SqlDataAdapter sqlData = new SqlDataAdapter(sql, sqlserver);
                sqlData.Fill(ds);
            }
            sqlserver.Close();
            return ds;
        }
        //初始页面数据查询
        public DataSet basePage(out int count,out int dataamount,int i)
        {
            string Constr = Properties.Settings.Default.DataString;
            SqlConnection sqlserver = new SqlConnection(Constr);
            DataSet ds = new DataSet();
            sqlserver.Open();
            dataamount = Dataamount;
            if (i == 1)
            {
                SqlCommand command = new SqlCommand("select count(*) from [dbo].[user]", sqlserver);
                count = Convert.ToInt32(command.ExecuteScalar());
                string sql = "select Top " + dataamount + " * from [dbo].[user]";
                SqlDataAdapter sqlData = new SqlDataAdapter(sql, sqlserver);
                sqlData.Fill(ds);
            }
            else if (i == 2)
            {
                string str = "select count(*) from [dbo].[u_prof] where State='"+ "待审批" + "'";
                SqlCommand cmd = new SqlCommand(str, sqlserver);
                count = Convert.ToInt32(cmd.ExecuteScalar());
                string sql = "select Top " + dataamount + " [dbo].[u_prof].Id,[dbo].[user].Name,[dbo].[prof].Name,Amount,State,btime,atime  from [dbo].[u_prof],[dbo].[prof],[dbo].[user] where State='" + "待审批" + "' and [dbo].[u_prof].uId=[dbo].[user].Id and [dbo].[u_prof].pId=[dbo].[prof].Id";
                SqlDataAdapter sqlData = new SqlDataAdapter(sql, sqlserver);
                sqlData.Fill(ds);
            }
            else
            {
                string str = "select count(*) from [dbo].[u_prof] where State='" + "已审批" + "'";
                SqlCommand cmd = new SqlCommand(str, sqlserver);
                count = Convert.ToInt32(cmd.ExecuteScalar());
                string sql = "select Top " + dataamount + " [dbo].[u_prof].Id,[dbo].[user].Name,[dbo].[prof].Name,Amount,State,btime,atime  from [dbo].[u_prof],[dbo].[prof],[dbo].[user] where State='" + "已审批" + "' and [dbo].[u_prof].uId=[dbo].[user].Id and [dbo].[u_prof].pId=[dbo].[prof].Id";
                SqlDataAdapter sqlData = new SqlDataAdapter(sql, sqlserver);
                sqlData.Fill(ds);
            }
            sqlserver.Close();
            return ds;
        }

        //翻页数据查询
        public DataSet Page(string page,int i) {
            string Constr = Properties.Settings.Default.DataString;
            DataSet dt = new DataSet();
            SqlConnection sqlserver = new SqlConnection(Constr);
            sqlserver.Open();
            int first = int.Parse(page) * Dataamount;
            int last = (int.Parse(page) - 1) * Dataamount;
            string sql = null;
            if (i == 1) {
                sql = "select Top " + first + " * from [dbo].[user] except select Top " + last + " * from [dbo].[user]";
            }
            else if (i == 2) {
                sql = "select Top " + first + " [dbo].[u_prof].Id,[dbo].[user].Name,[dbo].[prof].Name,Amount,State,btime,atime  from [dbo].[u_prof],[dbo].[prof],[dbo].[user] where State='" + "待审批" + "' and [dbo].[u_prof].uId=[dbo].[user].Id and [dbo].[u_prof].pId=[dbo].[prof].Id except select Top " + last + " [dbo].[u_prof].Id,[dbo].[user].Name,[dbo].[prof].Name,Amount,State,btime,atime  from [dbo].[u_prof],[dbo].[prof],[dbo].[user] where State='" + "待审批" + "' and [dbo].[u_prof].uId=[dbo].[user].Id and [dbo].[u_prof].pId=[dbo].[prof].Id";
            }
            else
            {
                sql = "select Top " + first + " [dbo].[u_prof].Id,[dbo].[user].Name,[dbo].[prof].Name,Amount,State,btime,atime  from [dbo].[u_prof],[dbo].[prof],[dbo].[user] where State='" + "已审批" + "' and [dbo].[u_prof].uId=[dbo].[user].Id and [dbo].[u_prof].pId=[dbo].[prof].Id except select Top " + last + " [dbo].[u_prof].Id,[dbo].[user].Name,[dbo].[prof].Name,Amount,State,btime,atime  from [dbo].[u_prof],[dbo].[prof],[dbo].[user] where State='" + "已审批" + "' and [dbo].[u_prof].uId=[dbo].[user].Id and [dbo].[u_prof].pId=[dbo].[prof].Id";
            }
            SqlDataAdapter sqlData = new SqlDataAdapter(sql, sqlserver);
            sqlData.Fill(dt);
            sqlserver.Close();
            return dt;
        }
        //审批
        public void status(string id)
        {
            string connstr = Properties.Settings.Default.DataString;
            SqlConnection sqlserver = new SqlConnection(connstr);
            sqlserver.Open();
            string sql = "update [dbo].[u_prof] set State='已审批', atime='"+ DateTime.Now.ToString() +" ' where Id='"+ id +"'";
            SqlCommand cmd = new SqlCommand(sql, sqlserver);
            try{ cmd.ExecuteNonQuery(); }catch(Exception e) { return; }
            sqlserver.Close();
        }
    }
}
