﻿namespace Client毕业设计
{
    partial class Forget
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pwd2 = new System.Windows.Forms.Label();
            this.txtpwd2 = new System.Windows.Forms.TextBox();
            this.pwd = new System.Windows.Forms.Label();
            this.txtpwd = new System.Windows.Forms.TextBox();
            this.email = new System.Windows.Forms.Label();
            this.txtemail = new System.Windows.Forms.TextBox();
            this.title = new System.Windows.Forms.Label();
            this.principal = new System.Windows.Forms.Label();
            this.code = new System.Windows.Forms.Label();
            this.txtcode = new System.Windows.Forms.TextBox();
            this.ret = new System.Windows.Forms.Button();
            this.modify = new System.Windows.Forms.Button();
            this.labelCode = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // pwd2
            // 
            this.pwd2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pwd2.AutoSize = true;
            this.pwd2.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.pwd2.Location = new System.Drawing.Point(31, 150);
            this.pwd2.Name = "pwd2";
            this.pwd2.Size = new System.Drawing.Size(74, 22);
            this.pwd2.TabIndex = 33;
            this.pwd2.Text = "确认密码";
            // 
            // txtpwd2
            // 
            this.txtpwd2.Location = new System.Drawing.Point(111, 150);
            this.txtpwd2.Name = "txtpwd2";
            this.txtpwd2.Size = new System.Drawing.Size(197, 21);
            this.txtpwd2.TabIndex = 32;
            // 
            // pwd
            // 
            this.pwd.AutoSize = true;
            this.pwd.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.pwd.Location = new System.Drawing.Point(47, 106);
            this.pwd.Name = "pwd";
            this.pwd.Size = new System.Drawing.Size(58, 22);
            this.pwd.TabIndex = 31;
            this.pwd.Text = "新密码";
            // 
            // txtpwd
            // 
            this.txtpwd.Location = new System.Drawing.Point(111, 106);
            this.txtpwd.Name = "txtpwd";
            this.txtpwd.Size = new System.Drawing.Size(197, 21);
            this.txtpwd.TabIndex = 30;
            // 
            // email
            // 
            this.email.AutoSize = true;
            this.email.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.email.Location = new System.Drawing.Point(63, 64);
            this.email.Name = "email";
            this.email.Size = new System.Drawing.Size(42, 22);
            this.email.TabIndex = 29;
            this.email.Text = "邮箱";
            // 
            // txtemail
            // 
            this.txtemail.Location = new System.Drawing.Point(111, 64);
            this.txtemail.Name = "txtemail";
            this.txtemail.Size = new System.Drawing.Size(197, 21);
            this.txtemail.TabIndex = 28;
            // 
            // title
            // 
            this.title.AutoSize = true;
            this.title.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.title.Location = new System.Drawing.Point(147, 26);
            this.title.Name = "title";
            this.title.Size = new System.Drawing.Size(88, 26);
            this.title.TabIndex = 25;
            this.title.Text = "忘记密码";
            // 
            // principal
            // 
            this.principal.AutoSize = true;
            this.principal.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.principal.Location = new System.Drawing.Point(47, 64);
            this.principal.Name = "principal";
            this.principal.Size = new System.Drawing.Size(0, 22);
            this.principal.TabIndex = 24;
            // 
            // code
            // 
            this.code.AutoSize = true;
            this.code.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.code.Location = new System.Drawing.Point(47, 190);
            this.code.Name = "code";
            this.code.Size = new System.Drawing.Size(58, 22);
            this.code.TabIndex = 35;
            this.code.Text = "验证码";
            // 
            // txtcode
            // 
            this.txtcode.Location = new System.Drawing.Point(111, 190);
            this.txtcode.Name = "txtcode";
            this.txtcode.Size = new System.Drawing.Size(197, 21);
            this.txtcode.TabIndex = 34;
            // 
            // ret
            // 
            this.ret.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.ret.Location = new System.Drawing.Point(246, 238);
            this.ret.Name = "ret";
            this.ret.Size = new System.Drawing.Size(75, 23);
            this.ret.TabIndex = 36;
            this.ret.Text = "返回";
            this.ret.UseVisualStyleBackColor = true;
            this.ret.Click += new System.EventHandler(this.ret_Click);
            // 
            // modify
            // 
            this.modify.Location = new System.Drawing.Point(76, 238);
            this.modify.Name = "modify";
            this.modify.Size = new System.Drawing.Size(75, 23);
            this.modify.TabIndex = 37;
            this.modify.Text = "修改";
            this.modify.UseVisualStyleBackColor = true;
            this.modify.Click += new System.EventHandler(this.modify_Click);
            // 
            // labelCode
            // 
            this.labelCode.AutoSize = true;
            this.labelCode.Cursor = System.Windows.Forms.Cursors.Hand;
            this.labelCode.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.labelCode.ForeColor = System.Drawing.Color.Blue;
            this.labelCode.Location = new System.Drawing.Point(314, 193);
            this.labelCode.Name = "labelCode";
            this.labelCode.Size = new System.Drawing.Size(65, 12);
            this.labelCode.TabIndex = 38;
            this.labelCode.Text = "发送验证码";
            this.labelCode.Click += new System.EventHandler(this.labelCode_Click);
            // 
            // Forget
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.ret;
            this.ClientSize = new System.Drawing.Size(384, 284);
            this.Controls.Add(this.labelCode);
            this.Controls.Add(this.modify);
            this.Controls.Add(this.ret);
            this.Controls.Add(this.code);
            this.Controls.Add(this.txtcode);
            this.Controls.Add(this.pwd2);
            this.Controls.Add(this.txtpwd2);
            this.Controls.Add(this.pwd);
            this.Controls.Add(this.txtpwd);
            this.Controls.Add(this.email);
            this.Controls.Add(this.txtemail);
            this.Controls.Add(this.title);
            this.Controls.Add(this.principal);
            this.MaximizeBox = false;
            this.Name = "Forget";
            this.Text = "forget";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label pwd2;
        private System.Windows.Forms.TextBox txtpwd2;
        private System.Windows.Forms.Label pwd;
        private System.Windows.Forms.TextBox txtpwd;
        private System.Windows.Forms.Label email;
        private System.Windows.Forms.TextBox txtemail;
        private System.Windows.Forms.Label title;
        private System.Windows.Forms.Label principal;
        private System.Windows.Forms.Label code;
        private System.Windows.Forms.TextBox txtcode;
        private System.Windows.Forms.Button ret;
        private System.Windows.Forms.Button modify;
        private System.Windows.Forms.Label labelCode;
    }
}