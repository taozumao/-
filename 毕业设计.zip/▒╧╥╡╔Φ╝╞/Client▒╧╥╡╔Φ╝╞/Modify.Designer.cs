﻿namespace Client毕业设计
{
    partial class Modify
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pwd2 = new System.Windows.Forms.Label();
            this.txtpwd2 = new System.Windows.Forms.TextBox();
            this.pwd = new System.Windows.Forms.Label();
            this.txtpwd = new System.Windows.Forms.TextBox();
            this.email = new System.Windows.Forms.Label();
            this.txtemail = new System.Windows.Forms.TextBox();
            this.phone = new System.Windows.Forms.Label();
            this.txtphone = new System.Windows.Forms.TextBox();
            this.principal = new System.Windows.Forms.Label();
            this.name = new System.Windows.Forms.Label();
            this.txtprincipal = new System.Windows.Forms.TextBox();
            this.txtname = new System.Windows.Forms.TextBox();
            this.btnYES = new System.Windows.Forms.Button();
            this.btnNO = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // pwd2
            // 
            this.pwd2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pwd2.AutoSize = true;
            this.pwd2.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.pwd2.Location = new System.Drawing.Point(11, 233);
            this.pwd2.Name = "pwd2";
            this.pwd2.Size = new System.Drawing.Size(74, 22);
            this.pwd2.TabIndex = 32;
            this.pwd2.Text = "确认密码";
            // 
            // txtpwd2
            // 
            this.txtpwd2.Location = new System.Drawing.Point(91, 233);
            this.txtpwd2.Name = "txtpwd2";
            this.txtpwd2.Size = new System.Drawing.Size(197, 21);
            this.txtpwd2.TabIndex = 31;
            // 
            // pwd
            // 
            this.pwd.AutoSize = true;
            this.pwd.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.pwd.Location = new System.Drawing.Point(43, 193);
            this.pwd.Name = "pwd";
            this.pwd.Size = new System.Drawing.Size(42, 22);
            this.pwd.TabIndex = 30;
            this.pwd.Text = "密码";
            // 
            // txtpwd
            // 
            this.txtpwd.Location = new System.Drawing.Point(91, 193);
            this.txtpwd.Name = "txtpwd";
            this.txtpwd.Size = new System.Drawing.Size(197, 21);
            this.txtpwd.TabIndex = 29;
            // 
            // email
            // 
            this.email.AutoSize = true;
            this.email.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.email.Location = new System.Drawing.Point(43, 151);
            this.email.Name = "email";
            this.email.Size = new System.Drawing.Size(42, 22);
            this.email.TabIndex = 28;
            this.email.Text = "邮箱";
            // 
            // txtemail
            // 
            this.txtemail.Location = new System.Drawing.Point(91, 151);
            this.txtemail.Name = "txtemail";
            this.txtemail.Size = new System.Drawing.Size(197, 21);
            this.txtemail.TabIndex = 27;
            // 
            // phone
            // 
            this.phone.AutoSize = true;
            this.phone.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.phone.Location = new System.Drawing.Point(43, 108);
            this.phone.Name = "phone";
            this.phone.Size = new System.Drawing.Size(42, 22);
            this.phone.TabIndex = 26;
            this.phone.Text = "电话";
            // 
            // txtphone
            // 
            this.txtphone.Location = new System.Drawing.Point(91, 108);
            this.txtphone.Name = "txtphone";
            this.txtphone.Size = new System.Drawing.Size(197, 21);
            this.txtphone.TabIndex = 25;
            // 
            // principal
            // 
            this.principal.AutoSize = true;
            this.principal.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.principal.Location = new System.Drawing.Point(27, 67);
            this.principal.Name = "principal";
            this.principal.Size = new System.Drawing.Size(58, 22);
            this.principal.TabIndex = 24;
            this.principal.Text = "负责人";
            // 
            // name
            // 
            this.name.AutoSize = true;
            this.name.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.name.Location = new System.Drawing.Point(43, 23);
            this.name.Name = "name";
            this.name.Size = new System.Drawing.Size(42, 22);
            this.name.TabIndex = 23;
            this.name.Text = "名称";
            // 
            // txtprincipal
            // 
            this.txtprincipal.Location = new System.Drawing.Point(91, 67);
            this.txtprincipal.Name = "txtprincipal";
            this.txtprincipal.Size = new System.Drawing.Size(197, 21);
            this.txtprincipal.TabIndex = 22;
            // 
            // txtname
            // 
            this.txtname.Location = new System.Drawing.Point(91, 24);
            this.txtname.Name = "txtname";
            this.txtname.Size = new System.Drawing.Size(197, 21);
            this.txtname.TabIndex = 21;
            // 
            // btnYES
            // 
            this.btnYES.Location = new System.Drawing.Point(177, 268);
            this.btnYES.Name = "btnYES";
            this.btnYES.Size = new System.Drawing.Size(75, 23);
            this.btnYES.TabIndex = 34;
            this.btnYES.Text = "确定";
            this.btnYES.UseVisualStyleBackColor = true;
            this.btnYES.Click += new System.EventHandler(this.btnYES_Click);
            // 
            // btnNO
            // 
            this.btnNO.Location = new System.Drawing.Point(57, 268);
            this.btnNO.Name = "btnNO";
            this.btnNO.Size = new System.Drawing.Size(75, 23);
            this.btnNO.TabIndex = 33;
            this.btnNO.Text = "取消";
            this.btnNO.UseVisualStyleBackColor = true;
            this.btnNO.Click += new System.EventHandler(this.btnNO_Click);
            // 
            // Modify
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(315, 303);
            this.Controls.Add(this.btnYES);
            this.Controls.Add(this.btnNO);
            this.Controls.Add(this.pwd2);
            this.Controls.Add(this.txtpwd2);
            this.Controls.Add(this.pwd);
            this.Controls.Add(this.txtpwd);
            this.Controls.Add(this.email);
            this.Controls.Add(this.txtemail);
            this.Controls.Add(this.phone);
            this.Controls.Add(this.txtphone);
            this.Controls.Add(this.principal);
            this.Controls.Add(this.name);
            this.Controls.Add(this.txtprincipal);
            this.Controls.Add(this.txtname);
            this.Name = "Modify";
            this.Text = "Modify";
            this.Load += new System.EventHandler(this.Modify_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label pwd2;
        private System.Windows.Forms.TextBox txtpwd2;
        private System.Windows.Forms.Label pwd;
        private System.Windows.Forms.TextBox txtpwd;
        private System.Windows.Forms.Label email;
        private System.Windows.Forms.TextBox txtemail;
        private System.Windows.Forms.Label phone;
        private System.Windows.Forms.TextBox txtphone;
        private System.Windows.Forms.Label principal;
        private System.Windows.Forms.Label name;
        private System.Windows.Forms.TextBox txtprincipal;
        private System.Windows.Forms.TextBox txtname;
        private System.Windows.Forms.Button btnYES;
        private System.Windows.Forms.Button btnNO;
    }
}