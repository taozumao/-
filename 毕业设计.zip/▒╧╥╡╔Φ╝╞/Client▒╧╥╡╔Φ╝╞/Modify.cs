﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Windows.Forms;

namespace Client毕业设计
{
    public partial class Modify : Form
    {
        public Modify(object obj1,object obj2)
        {
            InitializeComponent();
            dt = (CData)obj1;
            ck = (Clink)obj2;
        }
        CData dt = new CData();
        Clink ck = new Clink();

        private void Modify_Load(object sender, EventArgs e)
        {
            txtname.Text = dt.user.Tables[0].Rows[0]["Name"].ToString();
            txtprincipal.Text = dt.user.Tables[0].Rows[0]["Principal"].ToString();
            txtphone.Text = dt.user.Tables[0].Rows[0]["Phone"].ToString();
            txtemail.Text = dt.user.Tables[0].Rows[0]["Email"].ToString();
            txtpwd.Text = dt.user.Tables[0].Rows[0]["Psword"].ToString();
        }

        private void btnNO_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        //确认修改
        private void btnYES_Click(object sender, EventArgs e)
        {
            if (txtpwd.Text == txtpwd2.Text)
            {
                string sql = "SQL0"+"|"+"update [dbo].[user] set Name='" + txtname.Text + "',Principal='" + txtprincipal.Text + "',Phone='" + txtphone.Text + "',Email='" + txtemail.Text + "',Psword='" + txtpwd.Text + "' where Id='"+dt.user.Tables[0].Rows[0]["Id"]+"' ";
                try
                {
                    ck.send(sql);
                }catch(Exception ex) { MessageBox.Show(ex.ToString()); }
                Thread.Sleep(2000);
                if (dt.result)
                {
                    dt.result = false;
                    MessageBox.Show("更新成功!");
                    string ms = "updateAll" + "|" + txtname.Text + "|" + txtprincipal.Text + "|" + txtphone.Text + "|" + txtemail.Text + "|" + txtpwd.Text;
                    dt.DealDataSet(ms);
                    this.Close();
                }
                else { MessageBox.Show("更新失败，详细请咨询管理员!"); }
            }
            else { MessageBox.Show("密码不一致！"); }
            
        }
    }
}
