﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Client毕业设计
{
    public partial class Main : Form
    {
        public Main(object obj1,object obj2)
        {
            InitializeComponent();
            information.AutoGenerateColumns = false;
            top.Controls.Add(Menu1);
            top.Controls.Add(logout);
            left.Controls.Add(welcom);
            left.Controls.Add(btnModify);
            left.Controls.Add(labelname);
            right.Controls.Add(information);
            dt = (CData)obj1;
            link = (Clink)obj2;
            label1.Enabled = false;

        }
        //关于
        private void to_Click(object sender, EventArgs e)
        {
            GuanYu gy = new GuanYu();
            gy.StartPosition = FormStartPosition.Manual;
            gy.Location = new Point(this.Location.X + (this.Width - gy.Width) / 2, this.Location.Y + (this.Height - gy.Height) / 2);
            gy.ShowDialog();
        }
        //注销
        private void logout_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Login login = new Login();
            login.Owner = this;
            this.Hide();
            login.ShowDialog();
            Application.ExitThread();
        }
        public string str;
        Clink link = new Clink();
        CData dt = new CData();
        private void Main_Load(object sender, EventArgs e)
        {
            link.main = this;
            link.send("SQL2" + "|" + str);
            Thread.Sleep(2000);
            Page.Text = "1";
            information.DataSource = dt.information(int.Parse(Page.Text)).Tables[0];
            allPage.Text = "共"+ dt.Amount.ToString() +"数据";
        }
        //修改信息
        private void modify_Click(object sender, EventArgs e)
        {
            Object obj1 = (Object)dt;
            Object obj2 = (object)link;
            Modify modify = new Modify(obj1, obj2);
            modify.StartPosition = FormStartPosition.Manual;
            modify.Location = new Point(this.Location.X + (this.Width - modify.Width) / 2, this.Location.Y + (this.Height - modify.Height) / 2);
            modify.ShowDialog();
            information.DataSource = dt.information(int.Parse(Page.Text)).Tables[0];
        }
        //首页
        private void first_Click(object sender, EventArgs e)
        {
            Page.Text = "1";
            information.DataSource = dt.information(int.Parse(Page.Text)).Tables[0];
        }
        //上一页
        private void front_Click(object sender, EventArgs e)
        {
            information.DataSource = dt.information(int.Parse(Page.Text) - 1).Tables[0];
            if (int.Parse(Page.Text) > 1)
            {
                Page.Text = (int.Parse(Page.Text) - 1).ToString();
            }
            else { Page.Text = "1"; }
        }
        //下一页
        private void after_Click(object sender, EventArgs e)
        {
            information.DataSource = dt.information(int.Parse(Page.Text)+1).Tables[0];
            if (int.Parse(Page.Text)<dt.PageNum)
            {
                Page.Text = (int.Parse(Page.Text) + 1).ToString();
            }
            else { Page.Text = dt.PageNum.ToString(); }
        }
        //末页
        private void last_Click(object sender, EventArgs e)
        {
            information.DataSource = dt.information(32767).Tables[0];
            Page.Text = dt.PageNum.ToString();
        }
        //跳转
        private void jump_Click(object sender, EventArgs e)
        {
            information.DataSource = dt.information(int.Parse(Page.Text)).Tables[0];
        }
        //导出数据
        private void export_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFile = new SaveFileDialog { Filter = "所有文件(*xls)|*.xls" }; 
            saveFile.FilterIndex = 1;
            saveFile.RestoreDirectory = true;
            if (saveFile.ShowDialog() == DialogResult.OK)
            {
                Microsoft.Office.Interop.Excel.Application application = new Microsoft.Office.Interop.Excel.Application();
                if (application == null)
                {
                    MessageBox.Show("未安装Office!");
                    return;
                }
                Microsoft.Office.Interop.Excel.Workbook workbook = application.Workbooks.Add(Microsoft.Office.Interop.Excel.XlWBATemplate.xlWBATWorksheet);
                Microsoft.Office.Interop.Excel.Worksheet worksheet = (Microsoft.Office.Interop.Excel.Worksheet)workbook.Worksheets[1];
                worksheet.Name = "所有数据";
                ProgressBar.Maximum = (information.ColumnCount - 2) * dt.Amount;
                for (int i = 1; i < information.ColumnCount; i++)
                {
                    worksheet.Cells[1][i + 1] = information.Columns[i].HeaderText;
                    for (int j = 0; j < dt.Amount; j++)
                    {
                        ProgressBar.PerformStep();
                        worksheet.Cells[j + 2, i + 1] = dt.state.Tables[0].Rows[j][information.Columns[i].DataPropertyName];
                    }
                }
                try
                {
                    workbook.Saved = true;
                    workbook.SaveCopyAs(saveFile.FileName);
                }catch(Exception ex) { MessageBox.Show("文件已被打开!"); }
                application.Visible = false;
                System.Runtime.InteropServices.Marshal.ReleaseComObject(worksheet);
                System.Runtime.InteropServices.Marshal.ReleaseComObject(workbook);
                application.Quit();
                int w = System.GC.GetGeneration(application);
                application = null;
                System.GC.Collect(w);
            }
        }
        //点击删除按钮
        private void information_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if(e.RowIndex>=0)
            {
                if(information.Columns[e.ColumnIndex] is DataGridViewButtonColumn)
                {
                    if(MessageBox.Show("是否删除?","提示",MessageBoxButtons.YesNo,MessageBoxIcon.Question)==DialogResult.Yes)
                    {
                        string sql ="SQL0"+"|"+ "delete from [dbo].[u_prof] where Id='" + information.CurrentRow.Cells["DataId"].Value.ToString() + "'";
                        try
                        {
                            link.send(sql);
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show(ex.ToString());
                        }
                        Thread.Sleep(2000);
                        bool result = dt.result;
                        if (result)
                        {
                            dt.result = false;
                            MessageBox.Show("删除成功!");
                            string ms = "delete" + "|" + information.CurrentRow.Cells["DataId"].Value.ToString();
                            dt.DealDataSet(ms);
                            information.DataSource = dt.information(int.Parse(Page.Text)).Tables[0];
                            allPage.Text = "共" + dt.Amount.ToString() + "数据";
                        }
                        else { MessageBox.Show("删除失败，详细请咨询管理员!"); }
                    }
                }
            }
        }
        //申请
        private void btnApply_Click(object sender, EventArgs e)
        {
            Object obj1 = (Object)dt;
            Object obj2 = (object)link;
            Apply apply = new Apply(obj1, obj2);
            apply.StartPosition = FormStartPosition.Manual;
            apply.Location = new Point(this.Location.X + (this.Width - apply.Width) / 2, this.Location.Y + (this.Height - apply.Height) / 2);
            apply.ShowDialog();
            information.DataSource = dt.information(int.Parse(Page.Text)).Tables[0];
            allPage.Text = "共" + dt.Amount.ToString() + "数据";
        }

        private void label1_Click(object sender, EventArgs e)
        {
            try
            {
                link.link(dt);
                link.stop = true;
                label1.Text = "已连接";
                label1.Enabled = false;
            }
            catch (Exception ex)
            {
                label1.Text = "点击重连";
                MessageBox.Show("连接失败!" + ex.ToString());
            }
        }

        private void Main_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (MessageBox.Show("关闭窗口？", "提示", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                link.OnStop();
                Environment.Exit(0);
            }
        }
    }
}
