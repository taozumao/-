﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Net;
using System.Net.Mail;
using System.Windows.Forms;

namespace Client毕业设计
{
    public partial class Register : Form
    {
        public Register(object obj1, object obj2)
        {
            InitializeComponent();
            
            dt = (CData)obj1;
            ck = (Clink)obj2;
        }
        CData dt = new CData();
        Clink ck = new Clink();
        /// <summary>
        /// 返回登录界面
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ret_Click(object sender, EventArgs e)
        {
            Login login = new Login();
            login.Owner = this;
            this.Hide();
            login.ShowDialog();
            Application.ExitThread();
        }
        Random rand = new Random();
        //注册
        private void reg_Click(object sender, EventArgs e)
        {
            if (txtname.Text == null || txtphone.Text == null || txtemail.Text == null || txtpwd.Text == null || txtpwd2.Text == null || txtprincipal.Text == null||txtcode==null)
            {
                MessageBox.Show("不能为空");
            }
            else
            {
                if (txtpwd.Text == txtpwd2.Text)
                {
                    if (txtcode.Text == num.ToString())
                    {
                        string sql = "SQL0" + "|" + "insert into [dbo].[user] values('" + txtname.Text + "','" + principal.Text + "','" + txtphone.Text + "','" + txtemail.Text + "','" + txtpwd.Text + "')";
                        try
                        {
                            ck.send(sql);
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show(ex.ToString());
                        }
                        Thread.Sleep(2000);
                        if (dt.result)
                        {
                            dt.result = false;
                            MessageBox.Show("注册成功!");
                            ret_Click(sender, e);
                        }
                        else { MessageBox.Show("注册失败，请联系管理员解决!"); }
                    }
                    else { MessageBox.Show("验证码错误!"); }
                }
                else { MessageBox.Show("两次密码不一致!"); }
            }
            
        }
        static int num;
        //发送验证码
        private void labelCode_Click(object sender, EventArgs e)
        {
            Random rd = new Random();
            num = rd.Next(1000, 10000);
            string fjrEmail = "taozumao@qq.com";//发件人邮箱
            string fjrPsword = "spkjooagvanohhgj";//发件人密码
            string sjrEmail = txtemail.Text;//收件人邮箱
            string[] fasong = fjrEmail.Split('@');
            SmtpClient client = new SmtpClient("smtp." + fasong[1]);
            client.UseDefaultCredentials = false;
            client.DeliveryMethod = SmtpDeliveryMethod.Network;
            client.Credentials =new NetworkCredential(fjrEmail, fjrPsword);
            client.EnableSsl = true;
            MailMessage mail = new MailMessage();
            mail.From=new MailAddress(fjrEmail);
            mail.To.Add(new MailAddress(sjrEmail));
            mail.Subject = "验证码";
            mail.SubjectEncoding = Encoding.UTF8;
            mail.Body= "验证码:" + num.ToString();
            mail.BodyEncoding = Encoding.UTF8;
            mail.IsBodyHtml = true;
            mail.Priority = MailPriority.High;
            try
            {
                client.Send(mail);
                labelCode.Text = "成功发送";
            }catch(Exception ex)
            {
                MessageBox.Show("发送失败，请联系管理员解决!"+ex.ToString());
                labelCode.Text = "发送失败";
            }
        }
    }
}
