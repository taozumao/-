﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.Net.Sockets;
using System.IO;
using System.Threading;
using System.Windows.Forms;

namespace Client毕业设计
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
            Control.CheckForIllegalCrossThreadCalls = false;
        }
        Clink ck = new Clink();
        CData dt = new CData();
        //登录
        private void Input_Click(object sender, EventArgs e)
        {
            string msg = "SQL1"+"|" +"Select count(*) from [dbo].[user] where Email='"+ nametxt.Text +"' and Psword= '" + pwdtxt.Text + "'";
            try
            {
                 ck.send(msg);
            }catch(Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            Thread.Sleep(2000);
            bool result = dt.result;
            if (result)
            {
                dt.result = false;
                //ck.send("end");
                //Thread.Sleep(1000);
                //ck.Stop();
                Object obj1 = (Object)dt;
                Object obj2 = (object)ck;
                ck.login = null;
                Main main = new Main(obj1,obj2);
                main.Owner = this;
                main.str = nametxt.Text;
                this.Hide();
                main.ShowDialog();
                Application.ExitThread();
            }
        }
        //退出
        private void quit_Click(object sender, EventArgs e)
        {
            if(MessageBox.Show("确认关闭？","提示",MessageBoxButtons.YesNo,MessageBoxIcon.Question)==DialogResult.Yes)
            {
                ck.OnStop();
                Environment.Exit(0);
            }
        }

        private void Login_Load(object sender, EventArgs e)
        {
            ck.login = this;
            try
            {
                ck.link(dt);
                labelLink.Text = "已连接";
            }
            catch (Exception ex)
            {
                labelLink.Text = "点击重连";
                MessageBox.Show("连接失败!" + ex.ToString());
            }
            /*
            //服务器连接
            IPAddress ip = IPAddress.Parse("127.0.0.1");
            int port = 8888;
            Socket socket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            IPEndPoint point = new IPEndPoint(ip, port);
            try
            {
                socket.Connect(point);
                link = true;
            }catch(Exception ex) { }    */


        }
        /// <summary>
        /// 进入注册界面
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void reg_Click(object sender, EventArgs e)
        {
            Object obj1 = (Object)dt;
            Object obj2 = (object)ck;
            Register reg = new Register(obj1, obj2);
            reg.Owner = this;
            this.Hide();
            reg.ShowDialog();
            Application.ExitThread();
        }
        /// <summary>
        /// 忘记密码界面
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void forget_Click(object sender, EventArgs e)
        {
            Object obj1 = (Object)dt;
            Object obj2 = (object)ck;
            Forget forget = new Forget(obj1, obj2);
            forget.Owner = this;
            this.Hide();
            forget.ShowDialog();
            Application.ExitThread();
        }
        //重连服务端
        private void labelLink_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            try
            {
                ck.link(dt);
                ck.stop = true;
                labelLink.Text = "已连接";
                labelLink.Enabled = false;
            }
            catch (Exception ex)
            {
                labelLink.Text = "点击重连";
                MessageBox.Show("连接失败!" + ex.ToString());
            }
        }

        private void Login_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (MessageBox.Show("关闭窗口？", "提示", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                ck.OnStop();
                Environment.Exit(0);
            }
        }

    }
}
