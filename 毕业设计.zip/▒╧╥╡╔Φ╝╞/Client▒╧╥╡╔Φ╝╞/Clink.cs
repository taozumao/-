﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Net;
using System.Net.Sockets;
using System.Data;
using System.IO;

namespace Client毕业设计
{
    class Clink
    {
        Socket socket = null;
        public bool stop = true;
        CData dt = new CData();
        public Login login = null;
        public Main main = null;
        //连接服务器
        public void link(CData data)
        {
            dt = data;
            socket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            IPAddress ip = IPAddress.Parse("127.0.0.1");
            int port = 8888;
            IPEndPoint point = new IPEndPoint(ip, port);
            socket.Connect(point);
            Thread thread = new Thread(rec);
            thread.IsBackground = true;
            thread.Start();
        }
        //线程持续接收服务端发送的消息
        private void rec()
        {
            while (stop)
            {
                byte[] msg = new byte[1024 * 1024];
                int length = 0;
                try
                {
                    length = socket.Receive(msg);
                }catch(Exception ex) {
                    OnStop();
                }
                string message = Encoding.UTF8.GetString(msg, 0, length);
                if (message == "end")
                {
                    OnStop();
                }
                else
                {
                    dt.Dealmes(message);
                }
            }
        }
        //发送信息到服务端
        public void send(string msg)
        {
            byte[] sendmsg = Encoding.UTF8.GetBytes(msg);
            //socket.Send(sendmsg);
            try {
                socket.Send(sendmsg);
                
                //return true;
            }
            catch (Exception e)
            {
                
                //return false;
            }
        }
        public void OnStop()
        {
            stop = false;

            //Thread.CurrentThread.Abort();
            socket.Shutdown(SocketShutdown.Both);
            socket.Close();
            if (login != null)
            {
                login.Controls["labelLink"].Text = "未连接";
            }
            if(main!=null)
            {
                main.Controls["label1"].Text = "未连接";
            }
        }
    }
}
