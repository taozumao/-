﻿namespace Client毕业设计
{
    partial class Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Main));
            this.welcom = new System.Windows.Forms.Label();
            this.top = new System.Windows.Forms.Panel();
            this.Menu1 = new System.Windows.Forms.MenuStrip();
            this.menufile = new System.Windows.Forms.ToolStripMenuItem();
            this.menutool = new System.Windows.Forms.ToolStripMenuItem();
            this.menuto = new System.Windows.Forms.ToolStripMenuItem();
            this.logout = new System.Windows.Forms.LinkLabel();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.left = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.btnApply = new System.Windows.Forms.Button();
            this.btnModify = new System.Windows.Forms.Button();
            this.labelname = new System.Windows.Forms.Label();
            this.right = new System.Windows.Forms.Panel();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.first = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.front = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.after = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.last = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.Page = new System.Windows.Forms.ToolStripTextBox();
            this.jump = new System.Windows.Forms.ToolStripButton();
            this.allPage = new System.Windows.Forms.ToolStripLabel();
            this.export = new System.Windows.Forms.ToolStripButton();
            this.ProgressBar = new System.Windows.Forms.ToolStripProgressBar();
            this.information = new System.Windows.Forms.DataGridView();
            this.DataId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DataName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DataProf = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DataAmount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DataState = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DataBtime = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DataAtime = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DataDelete = new System.Windows.Forms.DataGridViewButtonColumn();
            this.top.SuspendLayout();
            this.Menu1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.left.SuspendLayout();
            this.right.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.information)).BeginInit();
            this.SuspendLayout();
            // 
            // welcom
            // 
            this.welcom.AutoSize = true;
            this.welcom.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.welcom.Location = new System.Drawing.Point(3, 25);
            this.welcom.Name = "welcom";
            this.welcom.Size = new System.Drawing.Size(26, 88);
            this.welcom.TabIndex = 0;
            this.welcom.Text = "欢\r\n迎\r\n您\r\n !";
            // 
            // top
            // 
            this.top.Controls.Add(this.Menu1);
            this.top.Controls.Add(this.logout);
            this.top.Controls.Add(this.tabControl1);
            this.top.Dock = System.Windows.Forms.DockStyle.Top;
            this.top.Location = new System.Drawing.Point(0, 0);
            this.top.Name = "top";
            this.top.Size = new System.Drawing.Size(546, 33);
            this.top.TabIndex = 4;
            // 
            // Menu1
            // 
            this.Menu1.Dock = System.Windows.Forms.DockStyle.None;
            this.Menu1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menufile,
            this.menutool,
            this.menuto});
            this.Menu1.Location = new System.Drawing.Point(2, 3);
            this.Menu1.Name = "Menu1";
            this.Menu1.Size = new System.Drawing.Size(140, 25);
            this.Menu1.TabIndex = 13;
            this.Menu1.Text = "menuStrip1";
            // 
            // menufile
            // 
            this.menufile.Name = "menufile";
            this.menufile.Size = new System.Drawing.Size(44, 21);
            this.menufile.Text = "文件";
            // 
            // menutool
            // 
            this.menutool.Name = "menutool";
            this.menutool.Size = new System.Drawing.Size(44, 21);
            this.menutool.Text = "工具";
            // 
            // menuto
            // 
            this.menuto.Name = "menuto";
            this.menuto.Size = new System.Drawing.Size(44, 21);
            this.menuto.Text = "关于";
            // 
            // logout
            // 
            this.logout.AutoSize = true;
            this.logout.Location = new System.Drawing.Point(494, 9);
            this.logout.Name = "logout";
            this.logout.Size = new System.Drawing.Size(29, 12);
            this.logout.TabIndex = 3;
            this.logout.TabStop = true;
            this.logout.Text = "注销";
            this.logout.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.logout_LinkClicked);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(0, 31);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(200, 227);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(192, 201);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "tabPage1";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // tabPage2
            // 
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(192, 201);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "tabPage2";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // left
            // 
            this.left.Controls.Add(this.label1);
            this.left.Controls.Add(this.btnApply);
            this.left.Controls.Add(this.btnModify);
            this.left.Controls.Add(this.labelname);
            this.left.Controls.Add(this.welcom);
            this.left.Location = new System.Drawing.Point(0, 31);
            this.left.Name = "left";
            this.left.Size = new System.Drawing.Size(62, 258);
            this.left.TabIndex = 8;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label1.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.Location = new System.Drawing.Point(1, 123);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(58, 22);
            this.label1.TabIndex = 4;
            this.label1.Text = "已连接";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // btnApply
            // 
            this.btnApply.Location = new System.Drawing.Point(0, 171);
            this.btnApply.Name = "btnApply";
            this.btnApply.Size = new System.Drawing.Size(57, 35);
            this.btnApply.TabIndex = 3;
            this.btnApply.Text = "申请";
            this.btnApply.UseVisualStyleBackColor = true;
            this.btnApply.Click += new System.EventHandler(this.btnApply_Click);
            // 
            // btnModify
            // 
            this.btnModify.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btnModify.Location = new System.Drawing.Point(0, 212);
            this.btnModify.Name = "btnModify";
            this.btnModify.Size = new System.Drawing.Size(57, 35);
            this.btnModify.TabIndex = 2;
            this.btnModify.Text = "修改\r\n信息";
            this.btnModify.UseVisualStyleBackColor = true;
            this.btnModify.Click += new System.EventHandler(this.modify_Click);
            // 
            // labelname
            // 
            this.labelname.AutoSize = true;
            this.labelname.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.labelname.Location = new System.Drawing.Point(32, 25);
            this.labelname.Name = "labelname";
            this.labelname.Size = new System.Drawing.Size(26, 88);
            this.labelname.TabIndex = 1;
            this.labelname.Text = "欢\r\n迎\r\n您\r\n !";
            // 
            // right
            // 
            this.right.Controls.Add(this.toolStrip1);
            this.right.Controls.Add(this.information);
            this.right.Location = new System.Drawing.Point(59, 31);
            this.right.Name = "right";
            this.right.Size = new System.Drawing.Size(485, 258);
            this.right.TabIndex = 10;
            // 
            // toolStrip1
            // 
            this.toolStrip1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.first,
            this.toolStripSeparator1,
            this.front,
            this.toolStripSeparator2,
            this.after,
            this.toolStripSeparator3,
            this.last,
            this.toolStripSeparator4,
            this.Page,
            this.jump,
            this.allPage,
            this.export,
            this.ProgressBar});
            this.toolStrip1.Location = new System.Drawing.Point(0, 233);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(485, 25);
            this.toolStrip1.TabIndex = 2;
            this.toolStrip1.Text = "分页";
            // 
            // first
            // 
            this.first.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.first.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.first.Name = "first";
            this.first.Size = new System.Drawing.Size(36, 22);
            this.first.Text = "首页";
            this.first.Click += new System.EventHandler(this.first_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // front
            // 
            this.front.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.front.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.front.Name = "front";
            this.front.Size = new System.Drawing.Size(48, 22);
            this.front.Text = "上一页";
            this.front.Click += new System.EventHandler(this.front_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // after
            // 
            this.after.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.after.Image = ((System.Drawing.Image)(resources.GetObject("after.Image")));
            this.after.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.after.Name = "after";
            this.after.Size = new System.Drawing.Size(48, 22);
            this.after.Text = "下一页";
            this.after.ToolTipText = "下一页";
            this.after.Click += new System.EventHandler(this.after_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(6, 25);
            // 
            // last
            // 
            this.last.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.last.Image = ((System.Drawing.Image)(resources.GetObject("last.Image")));
            this.last.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.last.Name = "last";
            this.last.Size = new System.Drawing.Size(36, 22);
            this.last.Text = "末页";
            this.last.ToolTipText = "末页";
            this.last.Click += new System.EventHandler(this.last_Click);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(6, 25);
            // 
            // Page
            // 
            this.Page.Name = "Page";
            this.Page.Size = new System.Drawing.Size(20, 25);
            this.Page.Text = "1";
            // 
            // jump
            // 
            this.jump.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.jump.Image = ((System.Drawing.Image)(resources.GetObject("jump.Image")));
            this.jump.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.jump.Name = "jump";
            this.jump.Size = new System.Drawing.Size(36, 22);
            this.jump.Text = "跳转";
            this.jump.Click += new System.EventHandler(this.jump_Click);
            // 
            // allPage
            // 
            this.allPage.Name = "allPage";
            this.allPage.Size = new System.Drawing.Size(54, 22);
            this.allPage.Text = "共**数据";
            // 
            // export
            // 
            this.export.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.export.Image = ((System.Drawing.Image)(resources.GetObject("export.Image")));
            this.export.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.export.Name = "export";
            this.export.Size = new System.Drawing.Size(36, 22);
            this.export.Text = "导出";
            this.export.Click += new System.EventHandler(this.export_Click);
            // 
            // ProgressBar
            // 
            this.ProgressBar.Name = "ProgressBar";
            this.ProgressBar.Size = new System.Drawing.Size(100, 22);
            this.ProgressBar.Step = 1;
            // 
            // information
            // 
            this.information.AllowUserToAddRows = false;
            this.information.AllowUserToDeleteRows = false;
            this.information.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.information.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.DataId,
            this.DataName,
            this.DataProf,
            this.DataAmount,
            this.DataState,
            this.DataBtime,
            this.DataAtime,
            this.DataDelete});
            this.information.Dock = System.Windows.Forms.DockStyle.Top;
            this.information.Location = new System.Drawing.Point(0, 0);
            this.information.Name = "information";
            this.information.ReadOnly = true;
            this.information.RowTemplate.Height = 23;
            this.information.Size = new System.Drawing.Size(485, 230);
            this.information.TabIndex = 0;
            this.information.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.information_CellContentClick);
            // 
            // DataId
            // 
            this.DataId.DataPropertyName = "Id";
            this.DataId.HeaderText = "ID";
            this.DataId.Name = "DataId";
            this.DataId.ReadOnly = true;
            this.DataId.Visible = false;
            this.DataId.Width = 16;
            // 
            // DataName
            // 
            this.DataName.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.DataName.DataPropertyName = "Name";
            this.DataName.FillWeight = 3F;
            this.DataName.HeaderText = "名称";
            this.DataName.Name = "DataName";
            this.DataName.ReadOnly = true;
            // 
            // DataProf
            // 
            this.DataProf.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.DataProf.DataPropertyName = "Name1";
            this.DataProf.FillWeight = 4F;
            this.DataProf.HeaderText = "污染物";
            this.DataProf.Name = "DataProf";
            this.DataProf.ReadOnly = true;
            // 
            // DataAmount
            // 
            this.DataAmount.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.DataAmount.DataPropertyName = "Amount";
            this.DataAmount.FillWeight = 3F;
            this.DataAmount.HeaderText = "数量";
            this.DataAmount.Name = "DataAmount";
            this.DataAmount.ReadOnly = true;
            // 
            // DataState
            // 
            this.DataState.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.DataState.DataPropertyName = "State";
            this.DataState.FillWeight = 3F;
            this.DataState.HeaderText = "状态";
            this.DataState.Name = "DataState";
            this.DataState.ReadOnly = true;
            // 
            // DataBtime
            // 
            this.DataBtime.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.DataBtime.DataPropertyName = "btime";
            this.DataBtime.FillWeight = 4F;
            this.DataBtime.HeaderText = "提交时间";
            this.DataBtime.Name = "DataBtime";
            this.DataBtime.ReadOnly = true;
            // 
            // DataAtime
            // 
            this.DataAtime.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.DataAtime.DataPropertyName = "atime";
            this.DataAtime.FillWeight = 4F;
            this.DataAtime.HeaderText = "审批时间";
            this.DataAtime.Name = "DataAtime";
            this.DataAtime.ReadOnly = true;
            // 
            // DataDelete
            // 
            this.DataDelete.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.DataDelete.FillWeight = 2F;
            this.DataDelete.HeaderText = "删除";
            this.DataDelete.Name = "DataDelete";
            this.DataDelete.ReadOnly = true;
            this.DataDelete.Text = "删除";
            this.DataDelete.UseColumnTextForButtonValue = true;
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(546, 290);
            this.Controls.Add(this.right);
            this.Controls.Add(this.left);
            this.Controls.Add(this.top);
            this.IsMdiContainer = true;
            this.MaximizeBox = false;
            this.Name = "Main";
            this.Text = "Main";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Main_FormClosing);
            this.Load += new System.EventHandler(this.Main_Load);
            this.top.ResumeLayout(false);
            this.top.PerformLayout();
            this.Menu1.ResumeLayout(false);
            this.Menu1.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.left.ResumeLayout(false);
            this.left.PerformLayout();
            this.right.ResumeLayout(false);
            this.right.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.information)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label welcom;
        private System.Windows.Forms.Panel top;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Panel left;
        private System.Windows.Forms.Button btnModify;
        private System.Windows.Forms.Label labelname;
        private System.Windows.Forms.LinkLabel logout;
        private System.Windows.Forms.Panel right;
        private System.Windows.Forms.DataGridView information;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton first;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripButton front;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripButton after;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripButton last;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripTextBox Page;
        private System.Windows.Forms.ToolStripButton jump;
        private System.Windows.Forms.ToolStripLabel allPage;
        private System.Windows.Forms.ToolStripButton export;
        private System.Windows.Forms.ToolStripProgressBar ProgressBar;
        private System.Windows.Forms.Button btnApply;
        private System.Windows.Forms.MenuStrip Menu1;
        private System.Windows.Forms.ToolStripMenuItem menufile;
        private System.Windows.Forms.ToolStripMenuItem menutool;
        private System.Windows.Forms.ToolStripMenuItem menuto;
        private System.Windows.Forms.DataGridViewTextBoxColumn DataId;
        private System.Windows.Forms.DataGridViewTextBoxColumn DataName;
        private System.Windows.Forms.DataGridViewTextBoxColumn DataProf;
        private System.Windows.Forms.DataGridViewTextBoxColumn DataAmount;
        private System.Windows.Forms.DataGridViewTextBoxColumn DataState;
        private System.Windows.Forms.DataGridViewTextBoxColumn DataBtime;
        private System.Windows.Forms.DataGridViewTextBoxColumn DataAtime;
        private System.Windows.Forms.DataGridViewButtonColumn DataDelete;
        public System.Windows.Forms.Label label1;
    }
}