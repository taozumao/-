﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace Client毕业设计
{
    class CData
    {
        int PageAmount = 1;//每页数量
        public int PageNum;//总页数
        public int Amount;//总数
        public int id;//数据库最大id，增行插入DataSet[Id]列
        public bool result = false;//数据库变更结果
        public DataSet user = null;//用户数据
        public DataSet state = null;//用户申请审批数据
        public DataSet prof = null;//污染源数据
        Decompilation decompilation = new Decompilation();
        //处理接收数据
        public void Dealmes(string mes) {
            
            string[] splited = mes.Split('|');
            if (splited[0] == "SQL")
            {
                if (int.Parse(splited[1]) > 0) 
                {
                    result = true;
                }
            }
            else if (splited[0] == "DataSetUser")
            {
                user = decompilation.DecompilationDataSet(splited);
            }
            else if (splited[0] == "DataSetState")
            {
                state = decompilation.DecompilationDataSet(splited);
                id = Convert.ToInt32(state.Tables[0].Rows[state.Tables[0].Rows.Count-1]["Id"]);
            }
            else if(splited[0]=="DataSetProf"){
                prof = decompilation.DecompilationDataSet(splited);
            }
        }
        //页面显示数据
        public DataSet information(int i)
        {
            Amount = state.Tables[0].Rows.Count;

            if (Amount%PageAmount==0)
            {
                PageNum = Amount / PageAmount;
            }
            else { PageNum = Amount / PageAmount + 1; }
            if (i > PageNum)
            {
                i = PageNum;
            }
            if (i < 1)
            {
                i = 1;
            }
            DataSet ds = new DataSet();
            ds = state.Clone();
            for(int num = (i - 1) * PageAmount; num < i * PageAmount; num++)
            {
                ds.Tables[0].ImportRow(state.Tables[0].Rows[num]);
                int j = ds.Tables[0].Rows.Count;
            }
            return ds;
            
        }
        //更新DataSet
        public void DealDataSet(string data)
        {
            string[] ms = data.Split('|');
            if(ms[0]=="delete")
            {
                for(int i = 0; i < state.Tables[0].Rows.Count; i++)
                {
                    if(state.Tables[0].Rows[i]["Id"].ToString() == ms[1])
                    {
                        state.Tables[0].Rows.RemoveAt(i);
                    }
                }
            }
            else if (ms[0] == "insertApply") {
                id = id + 1;
                DataRow dr = state.Tables[0].NewRow();
                dr["Id"] = id.ToString();
                dr["Name"] = user.Tables[0].Rows[0]["Name"];
                dr["Name1"] = ms[1];
                dr["Amount"] = ms[2];
                dr["State"] = "待审批";
                dr["btime"] = DateTime.Now.ToString();
                dr["atime"] = DBNull.Value;
                state.Tables[0].Rows.Add(dr);
            }
            else if (ms[0] == "updateAll")
            {
                user.Tables[0].Rows[0]["Name"] = ms[1].ToString();
                foreach(DataRow dr in state.Tables[0].Rows)
                {
                    dr["Name"] = ms[1];
                }
                user.Tables[0].Rows[0]["Principal"] = ms[2].ToString();
                user.Tables[0].Rows[0]["Phone"] = ms[3].ToString() ;
                user.Tables[0].Rows[0]["Email"] = ms[4].ToString();
                user.Tables[0].Rows[0]["Psword"] = ms[5].ToString();
            }
        }
    }
}
