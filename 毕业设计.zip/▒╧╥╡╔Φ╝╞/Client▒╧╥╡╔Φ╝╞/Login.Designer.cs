﻿namespace Client毕业设计
{
    partial class Login
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.Input = new System.Windows.Forms.Button();
            this.quit = new System.Windows.Forms.Button();
            this.title = new System.Windows.Forms.Label();
            this.pwd = new System.Windows.Forms.Label();
            this.nametxt = new System.Windows.Forms.TextBox();
            this.pwdtxt = new System.Windows.Forms.TextBox();
            this.author = new System.Windows.Forms.LinkLabel();
            this.name = new System.Windows.Forms.Label();
            this.reg = new System.Windows.Forms.Button();
            this.forget = new System.Windows.Forms.Button();
            this.labelLink = new System.Windows.Forms.LinkLabel();
            this.SuspendLayout();
            // 
            // Input
            // 
            this.Input.Location = new System.Drawing.Point(112, 189);
            this.Input.Name = "Input";
            this.Input.Size = new System.Drawing.Size(75, 23);
            this.Input.TabIndex = 3;
            this.Input.Text = "登录";
            this.Input.UseVisualStyleBackColor = true;
            this.Input.Click += new System.EventHandler(this.Input_Click);
            // 
            // quit
            // 
            this.quit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.quit.Location = new System.Drawing.Point(295, 189);
            this.quit.Name = "quit";
            this.quit.Size = new System.Drawing.Size(75, 23);
            this.quit.TabIndex = 4;
            this.quit.Text = "退出";
            this.quit.UseVisualStyleBackColor = true;
            this.quit.Click += new System.EventHandler(this.quit_Click);
            // 
            // title
            // 
            this.title.AutoSize = true;
            this.title.Font = new System.Drawing.Font("微软雅黑", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.title.Location = new System.Drawing.Point(154, 31);
            this.title.Name = "title";
            this.title.Size = new System.Drawing.Size(166, 28);
            this.title.TabIndex = 0;
            this.title.Text = "毕业设计-Client";
            // 
            // pwd
            // 
            this.pwd.AutoSize = true;
            this.pwd.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.pwd.Location = new System.Drawing.Point(130, 144);
            this.pwd.Name = "pwd";
            this.pwd.Size = new System.Drawing.Size(57, 22);
            this.pwd.TabIndex = 0;
            this.pwd.Text = "密   码";
            // 
            // nametxt
            // 
            this.nametxt.Location = new System.Drawing.Point(193, 98);
            this.nametxt.Name = "nametxt";
            this.nametxt.Size = new System.Drawing.Size(100, 21);
            this.nametxt.TabIndex = 1;
            this.nametxt.Text = "1277871614@qq.com";
            // 
            // pwdtxt
            // 
            this.pwdtxt.Location = new System.Drawing.Point(193, 144);
            this.pwdtxt.Name = "pwdtxt";
            this.pwdtxt.Size = new System.Drawing.Size(100, 21);
            this.pwdtxt.TabIndex = 2;
            this.pwdtxt.Text = "123";
            // 
            // author
            // 
            this.author.AutoSize = true;
            this.author.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.author.Location = new System.Drawing.Point(299, 59);
            this.author.Name = "author";
            this.author.Size = new System.Drawing.Size(69, 26);
            this.author.TabIndex = 0;
            this.author.TabStop = true;
            this.author.Text = "陶祖茂";
            // 
            // name
            // 
            this.name.AutoSize = true;
            this.name.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.name.Location = new System.Drawing.Point(129, 97);
            this.name.Name = "name";
            this.name.Size = new System.Drawing.Size(58, 22);
            this.name.TabIndex = 0;
            this.name.Text = "用户名";
            // 
            // reg
            // 
            this.reg.Location = new System.Drawing.Point(335, 5);
            this.reg.Name = "reg";
            this.reg.Size = new System.Drawing.Size(75, 23);
            this.reg.TabIndex = 5;
            this.reg.Text = "注册";
            this.reg.UseVisualStyleBackColor = true;
            this.reg.Click += new System.EventHandler(this.reg_Click);
            // 
            // forget
            // 
            this.forget.Location = new System.Drawing.Point(407, 5);
            this.forget.Name = "forget";
            this.forget.Size = new System.Drawing.Size(75, 23);
            this.forget.TabIndex = 6;
            this.forget.Text = "忘记密码";
            this.forget.UseVisualStyleBackColor = true;
            this.forget.Click += new System.EventHandler(this.forget_Click);
            // 
            // labelLink
            // 
            this.labelLink.AutoSize = true;
            this.labelLink.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.labelLink.Location = new System.Drawing.Point(12, 9);
            this.labelLink.Name = "labelLink";
            this.labelLink.Size = new System.Drawing.Size(107, 26);
            this.labelLink.TabIndex = 7;
            this.labelLink.TabStop = true;
            this.labelLink.Text = "服务器连接";
            this.labelLink.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.labelLink_LinkClicked);
            // 
            // Login
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.quit;
            this.ClientSize = new System.Drawing.Size(484, 261);
            this.Controls.Add(this.labelLink);
            this.Controls.Add(this.forget);
            this.Controls.Add(this.reg);
            this.Controls.Add(this.name);
            this.Controls.Add(this.author);
            this.Controls.Add(this.pwdtxt);
            this.Controls.Add(this.nametxt);
            this.Controls.Add(this.pwd);
            this.Controls.Add(this.title);
            this.Controls.Add(this.quit);
            this.Controls.Add(this.Input);
            this.MaximizeBox = false;
            this.Name = "Login";
            this.Text = "毕业设计";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Login_FormClosing);
            this.Load += new System.EventHandler(this.Login_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Input;
        private System.Windows.Forms.Button quit;
        private System.Windows.Forms.Label title;
        private System.Windows.Forms.Label pwd;
        private System.Windows.Forms.TextBox nametxt;
        private System.Windows.Forms.TextBox pwdtxt;
        private System.Windows.Forms.LinkLabel author;
        private System.Windows.Forms.Label name;
        private System.Windows.Forms.Button reg;
        private System.Windows.Forms.Button forget;
        public System.Windows.Forms.LinkLabel labelLink;
    }
}

