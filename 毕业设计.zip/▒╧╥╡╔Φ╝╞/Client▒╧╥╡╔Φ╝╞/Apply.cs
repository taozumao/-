﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Windows.Forms;

namespace Client毕业设计
{
    public partial class Apply : Form
    {
        public Apply(Object obj1,object obj2)
        {
            InitializeComponent();
            dt = (CData)obj1;
            ck = (Clink)obj2;

        }
        Clink ck = new Clink();
        CData dt = new CData();
        private void Apply_Load(object sender, EventArgs e)
        {
            foreach(DataRow dr in dt.prof.Tables[0].Rows)
            {
                prof.Items.Add(dr["Name"]);
            }
        }
        //取消
        private void btnNO_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        //确定申请
        private void btnYES_Click(object sender, EventArgs e)
        {
            string sql = null;
            for (int i = 0; i < dt.prof.Tables[0].Rows.Count; i++)
            {
                if (dt.prof.Tables[0].Rows[i]["Name"].ToString() == prof.Text)
                {
                    sql = "SQL0" + "|" + "insert into [dbo].[u_prof] values('" + Convert.ToInt32(dt.user.Tables[0].Rows[0]["Id"]) + "','" + Convert.ToInt32(dt.prof.Tables[0].Rows[i]["Id"]) + "','" + Double.Parse(txtAmount.Text) + "','待审批','" + DateTime.Now.ToString() + "',Null)";
                }
            }
            try
            {
                ck.send(sql);
            }catch(Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            Thread.Sleep(2000);
            if (dt.result)
            {
                dt.result = false;
                MessageBox.Show("申请成功!");
                string ms = "insertApply" + "|" + prof.Text + "|" + txtAmount.Text;
                dt.DealDataSet(ms);
                this.Close();
            }
            else { MessageBox.Show("申请失败，详细请咨询管理员!"); }
        }
    }
}
