﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Data;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.Threading.Tasks;

namespace Client毕业设计
{
    class Decompilation
    {
        //反序列化Xml为DataSet
        public DataSet DecompilationDataSet(string[] msg)
        {
            DataSet ds = new DataSet();
            MemoryStream ms = new MemoryStream(Convert.FromBase64String(msg[1]));
            MemoryStream stream = new MemoryStream(Convert.FromBase64String(msg[2]));
            ds.ReadXmlSchema(ms);
            ds.ReadXml(stream);
            return ds;
        }
    }
}
